package com.mangatrad.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Serviço em primeiro plano que:
 *  1. mostra uma bolha flutuante;
 *  2. captura o ecrã (MediaProjection);
 *  3. faz OCR (ML Kit) e traduz EN -> PT (ML Kit, no telemóvel);
 *  4. desenha a tradução por cima do texto original.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_START = "com.mangatrad.app.START"
        const val ACTION_STOP = "com.mangatrad.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        private const val CHANNEL_ID = "mangatrad"
        private const val NOTIF_ID = 1

        private const val AUTO_INTERVAL_MS = 2500L   // pausa entre ciclos no modo automático
        private const val HIDE_DELAY_MS = 160L       // tempo para as sobreposições desaparecerem antes da captura
        private const val LONG_PRESS_MS = 600L
        private const val BUBBLE_ALPHA = 0.85f

        @Volatile
        var isRunning = false
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var bgThread: HandlerThread
    private lateinit var bgHandler: Handler
    private lateinit var windowManager: WindowManager

    // Vistas
    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var overlayView: TranslationOverlayView? = null

    // Captura de ecrã
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val frameLock = Any()
    private var latestImage: Image? = null
    private var screenW = 0
    private var screenH = 0
    private var screenDpi = 0

    // OCR e tradução
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.PORTUGUESE)
            .build()
    )
    @Volatile
    private var modelReady = false
    private val cache = HashMap<String, String>() // só usado na thread principal

    // Estado
    private val busy = AtomicBoolean(false)
    private var autoMode = false
    private var lastSignature: IntArray? = null

    private val autoRunnable = Runnable { trigger(force = false) }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bgThread = HandlerThread("mangatrad-bg").also { it.start() }
        bgHandler = Handler(bgThread.looper)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        when (intent.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                // Tem de ser chamado logo, antes de obter a MediaProjection.
                startForegroundCompat()
                if (isRunning) return START_NOT_STICKY

                val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
                if (data == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }

                val manager = getSystemService(MediaProjectionManager::class.java)
                val mp = try {
                    manager.getMediaProjection(code, data)
                } catch (e: Exception) {
                    null
                }
                if (mp == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                projection = mp
                val cb = object : MediaProjection.Callback() {
                    override fun onStop() {
                        mainHandler.post { stopSelf() }
                    }
                }
                projectionCallback = cb
                mp.registerCallback(cb, mainHandler) // obrigatório antes de criar o VirtualDisplay (Android 14+)

                isRunning = true
                setupCapture()
                createOverlayViews()
                prepareTranslationModel()
            }
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection == null) return
        // Rotação do ecrã: limpa a tradução e ajusta o tamanho da captura.
        overlayView?.setItems(emptyList())
        lastSignature = null
        setupCapture()
    }

    override fun onDestroy() {
        isRunning = false
        autoMode = false
        mainHandler.removeCallbacksAndMessages(null)

        try { overlayView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        overlayView = null
        bubble = null

        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        synchronized(frameLock) {
            latestImage?.close()
            latestImage = null
        }
        projectionCallback?.let { projection?.unregisterCallback(it) }
        projection?.stop()
        projection = null

        recognizer.close()
        translator.close()
        bgThread.quitSafely()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notificação

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat),
            getString(R.string.notif_stop),
            stopIntent
        ).build()

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openIntent)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
    }

    // ------------------------------------------------------------------ captura de ecrã

    private fun readScreenSize() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        screenDpi = dm.densityDpi
    }

    private val imageListener = ImageReader.OnImageAvailableListener { reader ->
        val image = try {
            reader.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (image != null) {
            synchronized(frameLock) {
                latestImage?.close()
                latestImage = image
            }
        }
    }

    private fun setupCapture() {
        readScreenSize()
        val reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3)
        reader.setOnImageAvailableListener(imageListener, bgHandler)

        synchronized(frameLock) {
            latestImage?.close()
            latestImage = null
        }
        val oldReader = imageReader
        imageReader = reader

        val display = virtualDisplay
        if (display == null) {
            virtualDisplay = projection?.createVirtualDisplay(
                "mangatrad",
                screenW, screenH, screenDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
        } else {
            display.resize(screenW, screenH, screenDpi)
            display.surface = reader.surface
        }
        oldReader?.close()
    }

    /** Converte a última imagem capturada num Bitmap com o tamanho exato do ecrã. */
    private fun grabBitmap(): Bitmap? {
        synchronized(frameLock) {
            val image = latestImage ?: return null
            return try {
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowPadding = plane.rowStride - pixelStride * image.width
                val wide = Bitmap.createBitmap(
                    image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
                )
                plane.buffer.rewind()
                wide.copyPixelsFromBuffer(plane.buffer)
                if (wide.width != image.width) {
                    val cropped = Bitmap.createBitmap(wide, 0, 0, image.width, image.height)
                    wide.recycle()
                    cropped
                } else {
                    wide
                }
            } catch (e: Exception) {
                null
            }
        }
    }

    /** Assinatura pequena do ecrã (luminosidade em grelha 48x48) para detetar se mudou. */
    private fun signature(bmp: Bitmap): IntArray {
        val n = 48
        val out = IntArray(n * n)
        for (j in 0 until n) {
            for (i in 0 until n) {
                val x = i * (bmp.width - 1) / (n - 1)
                val y = j * (bmp.height - 1) / (n - 1)
                val c = bmp.getPixel(x, y)
                out[j * n + i] = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
            }
        }
        return out
    }

    private fun sameSignature(a: IntArray, b: IntArray): Boolean {
        if (a.size != b.size) return false
        var total = 0L
        for (i in a.indices) total += abs(a[i] - b[i])
        return total.toDouble() / a.size < 3.0
    }

    // ------------------------------------------------------------------ ciclo de tradução

    private fun trigger(force: Boolean) {
        if (!modelReady) {
            toast(R.string.model_not_ready)
            scheduleNext()
            return
        }
        if (!busy.compareAndSet(false, true)) return

        // Esconde a tradução e a bolha para o OCR ler o texto original.
        overlayView?.visibility = View.INVISIBLE
        bubble?.alpha = 0f
        mainHandler.postDelayed({ bgHandler.post { processFrame(force) } }, HIDE_DELAY_MS)
    }

    private fun processFrame(force: Boolean) {
        val bmp = grabBitmap()
        mainHandler.post { bubble?.alpha = BUBBLE_ALPHA }

        if (bmp == null) {
            finishCycle()
            return
        }

        val sig = signature(bmp)
        val previous = lastSignature
        if (!force && previous != null && sameSignature(previous, sig)) {
            bmp.recycle()
            finishCycle() // ecrã igual: mantém a tradução que já está
            return
        }
        lastSignature = sig

        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                bmp.recycle()
                onTextRecognized(text)
            }
            .addOnFailureListener {
                bmp.recycle()
                finishCycle()
            }
    }

    private fun onTextRecognized(text: Text) {
        val blocks = text.textBlocks.mapNotNull { block ->
            val box = block.boundingBox ?: return@mapNotNull null
            val clean = cleanText(block.text) ?: return@mapNotNull null
            Pair(box, clean)
        }

        if (blocks.isEmpty()) {
            overlayView?.setItems(emptyList())
            if (!autoMode) toast(R.string.no_text)
            finishCycle()
            return
        }

        val tasks: List<Task<String>> = blocks.map { (_, source) ->
            val cached = cache[source]
            if (cached != null) Tasks.forResult(cached) else translator.translate(source)
        }

        Tasks.whenAllComplete(tasks).addOnCompleteListener {
            val items = ArrayList<TranslatedBlock>()
            blocks.forEachIndexed { index, (box, source) ->
                val task = tasks[index]
                if (task.isSuccessful) {
                    val translated = task.result
                    if (!translated.isNullOrBlank()) {
                        if (cache.size > 500) cache.clear()
                        cache[source] = translated
                        items.add(TranslatedBlock(box, translated))
                    }
                }
            }
            overlayView?.setItems(items)
            finishCycle()
        }
    }

    private fun finishCycle() {
        mainHandler.post {
            overlayView?.visibility = View.VISIBLE
            bubble?.alpha = BUBBLE_ALPHA
            busy.set(false)
            scheduleNext()
        }
    }

    private fun scheduleNext() {
        mainHandler.removeCallbacks(autoRunnable)
        if (autoMode) mainHandler.postDelayed(autoRunnable, AUTO_INTERVAL_MS)
    }

    /** Prepara o texto para tradução: junta linhas e converte MAIÚSCULAS em frase normal. */
    private fun cleanText(raw: String): String? {
        var s = raw.replace("-\n", "").replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        val letters = s.filter { it.isLetter() }
        if (letters.length < 2) return null

        val upper = letters.count { it.isUpperCase() }
        if (upper >= letters.length * 0.7) {
            s = s.lowercase()
            s = s.replace(Regex("\\bi\\b"), "I")
            s = s.replace(Regex("(^|[.!?]\\s+)([a-z])")) { m ->
                m.groupValues[1] + m.groupValues[2].uppercase()
            }
        }
        return s
    }

    // ------------------------------------------------------------------ modelo de tradução

    private fun prepareTranslationModel() {
        toast(R.string.model_downloading)
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                modelReady = true
                toast(R.string.model_ready)
            }
            .addOnFailureListener {
                toast(R.string.model_failed)
            }
    }

    // ------------------------------------------------------------------ bolha e sobreposição

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun createOverlayViews() {
        // 1) Vista da tradução: ecrã inteiro, sem apanhar toques.
        val overlay = TranslationOverlayView(this)
        val overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        windowManager.addView(overlay, overlayParams)
        overlayView = overlay

        // 2) Bolha flutuante (por cima da tradução).
        val size = dp(52)
        val tv = TextView(this).apply {
            text = "PT"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            alpha = BUBBLE_ALPHA
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1E88E5.toInt())
            }
        }
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }
        tv.setOnTouchListener(bubbleTouchListener(params))
        windowManager.addView(tv, params)
        bubble = tv
        bubbleParams = params
    }

    private fun bubbleTouchListener(params: WindowManager.LayoutParams) = object : View.OnTouchListener {
        private val slop = ViewConfiguration.get(this@OverlayService).scaledTouchSlop
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false
        private var longPressed = false
        private val longPress = Runnable {
            longPressed = true
            toggleAuto()
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    longPressed = false
                    mainHandler.postDelayed(longPress, LONG_PRESS_MS)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (!moved && hypot(dx, dy) > slop) {
                        moved = true
                        mainHandler.removeCallbacks(longPress)
                    }
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        try { windowManager.updateViewLayout(v, params) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPress)
                    if (e.action == MotionEvent.ACTION_UP && !moved && !longPressed) onBubbleTap()
                }
            }
            return true
        }
    }

    private fun onBubbleTap() {
        if (autoMode) {
            toggleAuto()
            clearTranslation()
        } else if (overlayView?.hasItems() == true) {
            clearTranslation()
        } else {
            trigger(force = true)
        }
    }

    private fun clearTranslation() {
        overlayView?.setItems(emptyList())
        lastSignature = null
    }

    private fun toggleAuto() {
        autoMode = !autoMode
        (bubble?.background as? GradientDrawable)
            ?.setColor(if (autoMode) 0xFF43A047.toInt() else 0xFF1E88E5.toInt())
        toast(if (autoMode) R.string.auto_on else R.string.auto_off)
        mainHandler.removeCallbacks(autoRunnable)
        if (autoMode) trigger(force = true)
    }

    private fun toast(resId: Int) {
        mainHandler.post { Toast.makeText(applicationContext, resId, Toast.LENGTH_SHORT).show() }
    }
}
