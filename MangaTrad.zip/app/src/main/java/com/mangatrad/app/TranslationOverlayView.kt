package com.mangatrad.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** Um bloco de texto reconhecido (caixa em píxeis do ecrã) já traduzido. */
data class TranslatedBlock(val box: Rect, val text: String)

/**
 * Vista que cobre o ecrã todo e desenha, por cima de cada balão de texto original,
 * uma caixa branca com a tradução ajustada ao tamanho do balão.
 */
class TranslationOverlayView(context: Context) : View(context) {

    private class Drawn(val rect: RectF, val layout: StaticLayout)

    private val density = resources.displayMetrics.density
    private val outerPad = 5f * density
    private val innerPad = 4f * density

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(245, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val baseTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private var drawn: List<Drawn> = emptyList()

    fun hasItems(): Boolean = drawn.isNotEmpty()

    fun setItems(items: List<TranslatedBlock>) {
        drawn = items.map { item ->
            val rect = RectF(item.box).apply { inset(-outerPad, -outerPad) }
            val innerW = (rect.width() - 2 * innerPad).toInt().coerceAtLeast(20)
            val innerH = (rect.height() - 2 * innerPad).toInt().coerceAtLeast(12)
            val layout = fit(item.text, innerW, innerH)

            // Se mesmo no tamanho mínimo o texto não cabe, cresce a caixa na vertical.
            val needed = layout.height + 2 * innerPad
            if (needed > rect.height()) {
                val extra = (needed - rect.height()) / 2f
                rect.inset(0f, -extra)
            }
            Drawn(rect, layout)
        }
        invalidate()
    }

    private fun fit(text: String, width: Int, height: Int): StaticLayout {
        val minSize = 9f * density
        val maxSize = maxOf(minSize, minOf(height.toFloat(), 40f * density))
        var size = maxSize
        var layout = buildLayout(text, width, size)
        while (layout.height > height && size > minSize) {
            size = maxOf(minSize, size - density)
            layout = buildLayout(text, width, size)
        }
        return layout
    }

    private fun buildLayout(text: String, width: Int, size: Float): StaticLayout {
        // Cada layout precisa do seu próprio TextPaint: o StaticLayout guarda a referência.
        val paint = TextPaint(baseTextPaint).apply { textSize = size }
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
    }

    override fun onDraw(canvas: Canvas) {
        val radius = 8f * density
        for (d in drawn) {
            canvas.drawRoundRect(d.rect, radius, radius, bgPaint)
            canvas.save()
            canvas.translate(
                d.rect.left + innerPad,
                d.rect.top + (d.rect.height() - d.layout.height) / 2f
            )
            d.layout.draw(canvas)
            canvas.restore()
        }
    }
}
