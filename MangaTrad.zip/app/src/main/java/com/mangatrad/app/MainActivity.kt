package com.mangatrad.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var overlayButton: Button

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val intent = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_START
                    putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(OverlayService.EXTRA_RESULT_DATA, data)
                }
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(this, R.string.started_toast, Toast.LENGTH_LONG).show()
                status.setText(R.string.status_running)
            } else {
                Toast.makeText(this, R.string.capture_denied, Toast.LENGTH_LONG).show()
            }
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Com ou sem permissão de notificações, seguimos para a captura de ecrã.
            launchProjection()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            setText(R.string.title)
            textSize = 28f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            setText(R.string.subtitle)
            textSize = 15f
            setPadding(0, dp(4), 0, dp(20))
        })

        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(status)

        overlayButton = Button(this).apply {
            setText(R.string.btn_overlay)
            setOnClickListener { openOverlaySettings() }
        }
        root.addView(overlayButton, buttonParams())

        root.addView(Button(this).apply {
            setText(R.string.btn_start)
            setOnClickListener { startTranslator() }
        }, buttonParams())

        root.addView(Button(this).apply {
            setText(R.string.btn_stop)
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_STOP
                })
                status.setText(R.string.status_stopped)
            }
        }, buttonParams())

        root.addView(TextView(this).apply {
            setText(R.string.help)
            textSize = 14f
            setPadding(0, dp(24), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val canOverlay = Settings.canDrawOverlays(this)
        overlayButton.visibility = if (canOverlay) View.GONE else View.VISIBLE
        status.setText(
            when {
                !canOverlay -> R.string.status_overlay_missing
                OverlayService.isRunning -> R.string.status_running
                else -> R.string.status_overlay_ok
            }
        )
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun startTranslator() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchProjection()
        }
    }

    private fun launchProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun buttonParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
