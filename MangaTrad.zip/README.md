# MangaTrad

Traduz manga em inglês para português **no ecrã do telemóvel, em tempo real**, em qualquer app de leitura.

Como funciona: bolha flutuante → captura de ecrã → OCR (ML Kit) → tradução EN→PT no telemóvel (ML Kit) → caixas brancas com a tradução por cima dos balões.

## Obter o APK (sem Android Studio)

1. Cria uma conta e um repositório novo (vazio) em https://github.com.
2. Carrega **todo o conteúdo desta pasta** para o repositório (incluindo a pasta oculta `.github`).
   - No site: *Add file → Upload files* e arrasta os ficheiros e pastas (num computador funciona com pastas).
   - Se a pasta `.github` não subir, usa *Add file → Create new file*, escreve `.github/workflows/build.yml` no nome e cola o conteúdo do ficheiro.
3. Abre o separador **Actions**. A compilação começa sozinha (ou escolhe *Compilar APK → Run workflow*). Demora uns 5 a 10 minutos.
4. Quando ficar verde, abre a execução e descarrega o artefacto **MangaTrad-apk** (um .zip com `app-debug.apk`).
5. Instala o APK no telemóvel (permite "instalar apps de fontes desconhecidas" quando pedido).

## Usar

1. Abre a MangaTrad → **Permitir bolha sobre outras apps** → **Iniciar tradutor** → escolhe **Ecrã inteiro** na janela de partilha.
2. Espera pelo aviso "Tradução pronta" (a 1.ª vez descarrega ~30 MB; precisa de internet).
3. Abre o teu leitor de manga e usa a bolha **PT**:
   - toque: traduz / limpa;
   - toque longo: modo automático (bolha verde), traduz sozinho enquanto fazes scroll;
   - arrastar: muda a bolha de sítio.

## Limitações

- OCR em texto latino (inglês). Scans com letra muito estilizada ou escrita à mão falham mais.
- Cada bloco de texto detetado é traduzido separadamente; balões muito próximos podem ser juntados.
- A tradução do ML Kit é automática e mais literal que a de um tradutor humano.
- Apps que bloqueiam capturas de ecrã mostram preto e não funcionam.
- No modo automático a tradução desaparece por instantes a cada ciclo para o OCR ler o original.

## Para mudar o idioma

Em `OverlayService.kt`, altera `setSourceLanguage` / `setTargetLanguage` (constantes `TranslateLanguage`).
Para texto japonês, coreano ou chinês troca a dependência `text-recognition` por `text-recognition-japanese` (ou `-korean`, `-chinese`) e o import/opções correspondentes.
